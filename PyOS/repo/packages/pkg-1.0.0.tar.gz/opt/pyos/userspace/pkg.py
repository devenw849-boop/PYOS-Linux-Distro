placeholder package manager source

